//
//  mmSaveEntityResult.m
//  MMiOS
//
//  Created by Kevin McNeish on 7/3/14.
//  Copyright (c) 2014 Oak Leaf Enterprises, Inc. All rights reserved.
//

#import "mmSaveEntityResult.h"

@implementation mmSaveEntityResult

@end
