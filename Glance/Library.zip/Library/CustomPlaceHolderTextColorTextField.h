//
//  CustomPlaceHolderTextColorTextField.h
//  LiquorStoreApp
//
//  Created by Vanguard on 11/5/14.
//  Copyright (c) 2014 ParthPatel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomPlaceHolderTextColorTextField : UITextField

@end
